using TestsApi.Models;
using TestsApi.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace TestsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly BookService _bookService;

        public ImagesController(BookService bookService)
        {
            _bookService = bookService;
        }

        [HttpGet]
        public ActionResult<List<Book>> Get() =>
            _bookService.Get();

        [HttpGet("{id:length(24)}", Name = "GetBook")]
        public ActionResult<Book> Get(string id)
        {
            var book = _bookService.Get(id);

            if (book == null)
            {
                return NotFound();
            }

            return book;
        }

         [HttpGet("category/{category}", Name = "GetBookByCategory")]
        public ActionResult<List<Book>> GetCategory(string category) => _bookService.GetCategory(category);

       [HttpPost]
        public ActionResult<Book> Create(Book book)
        {
            book = _bookService.Create(book);

            return book;
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Book bookIn)
        {
            var book = _bookService.Get(id);

            if (book == null)
            {
                return NotFound();
            }

            _bookService.Update(id, bookIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var book = _bookService.Get(id);

            if (book == null)
            {
                return NotFound();
            }

            _bookService.Remove(book.Id);

            return NoContent();
        }
    }
}
