using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TestsApi.Models
{
    public class Image
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

	[BsonElement("Name")] 
        public string Category { get; set; }

        public decimal Type { get; set; }

        public string ContentImage { get; set; }

        public string Name { get; set; }
    }
}
