using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TestsApi.Models
{
    public class Book
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

	public string ImageName {get; set;}
        public string Name { get; set; }

        public string Category { get; set; }

        public string ContentImage { get; set; }

        public string Url { get; set; }
    }
}
